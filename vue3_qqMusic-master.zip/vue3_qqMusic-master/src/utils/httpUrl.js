const publicData = 'http://47.109.193.125:3300'
export default publicData;