// 跳转单曲歌曲密钥
export const setMicKey = Symbol('setMic')