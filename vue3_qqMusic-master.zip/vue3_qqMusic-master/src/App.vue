<script setup>
</script>

<template>
  <div id="QQMusic">
    <router-view />
  </div>
</template>

<style scoped>
  #QQMusic {
    width: 100vw;
    height: 100vh;
  }
</style>